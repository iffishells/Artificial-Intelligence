#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np


# In[5]:


class Solver:

    def __init__(self,Environment,initial_state,goal_state):

        self.initial_state = initial_state
        self.goal_state = goal_state
        self.Environment=Environment
        self.current_state =initial_state
        self.visited_state = []

    def SettingUpEnvironment(self):

        # out Environment given

        print("Environment : ",self.Environment)

        # our initia state

        print("Initial State : ",self.initial_state)

        # our goal state

        print("Goal State  is  : ",self.goal_state)

        # our current State

        print("Current State : ",self.current_state)

    def right(self,mov):
        ''' Right() return the index of right fromt the Given Matrix'''
        
        print("Right mov")

        if mov[1]>=4:
            print("Wall :",mov)
            return mov
        else:
            RightMovedLocation = (mov[0],mov[1]+1)
            print("Toward :",RightMovedLocation)
            return RightMovedLocation
    def left(self,mov):
        '''left function return the index of the left move from the given matrix'''
        print("Left Move")

        if mov[1]>=0:
            print("Wall : ",mov)
            return mov

        else:
            leftMovedLocation = (mov[0],mov[1]-1)
            print("Toward left : ",leftMovedLocation)
            return leftMovedLocation
    
    def up(self,mov):
    # '''' Up function return the index of the up move from the given matriix'''
        
        print("Up Move")
        
        if mov[0]>=0:
            print("Wall : ",mov)
            return mov
        else:

            upMovedLocation = (mov[0]-1,mov[1])
            print("Toward : ",upMovedLocation)
            return upMovedLocation

    def down(self,mov):
        
        if mov[0]>=4:
            print("Wall :",mov)
            return mov
        else:
            DownMovedLocation = (mov[0]+1,mov[1])
            print("Toward : ",DownMovedLocation)
            return DownMovedLocation
    
    def BFS(self):

        Queue = []
        visited=[]
        print("Initial State : ",self.initial_state)

        Queue.append(self.initial_state)
        
        while len(Queue)>0:

            temp = Queue.pop(0)

            if temp not in visited:

                value =  self.Environment[temp[0]][temp[1]]
                print("Value : ",value)

                if value =="G":
                    print("Got it")
                    print("Queue : ",Queue)
                    print("Visited Node : ",visited)

                    return "Got it"

                action = self.left(temp) # for left mov 
                a1 = action
                Queue.append(action)

                action = self.right(temp) # for left mov 
                a2 = action
                Queue.append(action)
                
                action = self.up(temp) # for left mov 
                a3 = action
                Queue.append(action)
                
                action = self.down(temp) # for left mov 
                a4 = action
                Queue.append(action)
                
                print("Next possible state of ", value," : ",a1 , " : ",a2," : ",a3," : ",a4)

            visited.append(temp) 
            




# In[7]:


Environment = np.array([3,4,1,3,0,3,3,3,2,2,3,1,2,2,3,4,2,3,3,3,4,1,4,3,"G"]).reshape(5,5)
initial_state_location_first_index = int(input("Enter the location of the agent (for 5X5 matrix) : "))
initial_state_location_seconed_index = int(input("Enter the location of the agent (for 5X5 matrix): "))
initial_state =(initial_state_location_first_index ,initial_state_location_seconed_index  )
print(Environment)  

goal_state = (4,4)

s = Solver(Environment ,initial_state ,goal_state)
s.BFS()


# In[ ]:


1            




                






# In[ ]:





# In[ ]:


print(list_[0][-1])


# In[ ]:


get_ipython().system('tlp-stat -t')


# In[ ]:




